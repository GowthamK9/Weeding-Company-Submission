import pytest
from app import create_app
from app.extensions import db
from app.models import User

@pytest.fixture
def client(tmp_path):
    app = create_app()
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    app.config['TESTING'] = True
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
            u = User(email='test@example.com')
            u.set_password('pw')
            db.session.add(u)
            db.session.commit()
        yield client

def test_register_and_login(client):
    res = client.post('/api/auth/register', json={'email':'a@b.com','password':'pw123'})
    assert res.status_code == 201
    res = client.post('/api/auth/login', json={'email':'a@b.com','password':'pw123'})
    assert res.status_code == 200
    assert 'access_token' in res.get_json()
