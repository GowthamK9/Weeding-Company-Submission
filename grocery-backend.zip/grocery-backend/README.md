# Grocery Backend (Flask)

## Quick start
1. Create virtualenv & install:
   ```
   python -m venv venv
   source venv/bin/activate   # or venv\Scripts\activate on Windows
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and set values if needed.
3. Initialize DB (first time only):
   ```
   export FLASK_APP=run.py
   flask db init        # only first time
   flask db migrate -m "initial"
   flask db upgrade
   ```
4. Seed sample data:
   ```
   python -m app.seed
   ```
5. Run:
   ```
   python run.py
   ```

## Endpoints
- `POST /api/auth/register` {email, password}
- `POST /api/auth/login` {email, password} → returns access_token
- `GET /api/products/` → list products
- `POST /api/products/` (JWT protected) create product
- `GET /api/cart/` (JWT protected) view cart (pricing)
- `POST /api/cart/add` (JWT) {product_id, quantity}
- `POST /api/cart/update` (JWT) {cart_item_id, quantity}
- `POST /api/cart/checkout` (JWT) checkout and create order

## Notes
- Default DB: SQLite (grocery.db)
- Do NOT commit `.env` or DB files to GitHub.
