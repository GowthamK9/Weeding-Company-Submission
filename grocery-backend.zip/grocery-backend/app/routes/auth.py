from flask import Blueprint, request, jsonify
from ..extensions import db
from ..models import User
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')
    if not email or not password:
        return jsonify({"msg": "email and password required"}), 400
    if User.query.filter_by(email=email).first():
        return jsonify({"msg": "email exists"}), 400
    u = User(email=email)
    u.set_password(password)
    db.session.add(u)
    db.session.commit()
    return jsonify({"msg": "registered", "user_id": u.id}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    email = data.get('email')
    password = data.get('password')
    if not email or not password:
        return jsonify({"msg": "email and password required"}), 400
    u = User.query.filter_by(email=email).first()
    if not u or not u.check_password(password):
        return jsonify({"msg": "invalid credentials"}), 401
    access = create_access_token(identity=u.id)
    return jsonify({"access_token": access, "user_id": u.id}), 200

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def me():
    user_id = get_jwt_identity()
    u = User.query.get(user_id)
    return jsonify({"id": u.id, "email": u.email, "created_at": u.created_at.isoformat()})
