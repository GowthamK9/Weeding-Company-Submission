from flask import Blueprint, request, jsonify, current_app
from ..extensions import db
from ..models import CartItem, Product, Order
from flask_jwt_extended import jwt_required, get_jwt_identity
import json

cart_bp = Blueprint('cart', __name__)

def compute_cart_totals(items, tax_percent, discount_percent=0.0):
    subtotal = sum(i['unit_price'] * i['quantity'] for i in items)
    discount = subtotal * (discount_percent / 100.0)
    taxable = subtotal - discount
    tax = taxable * (tax_percent / 100.0)
    total = taxable + tax
    return {
        "items": items,
        "subtotal": round(subtotal, 2),
        "discount": round(discount, 2),
        "tax": round(tax, 2),
        "total": round(total, 2)
    }

@cart_bp.route('/', methods=['GET'])
@jwt_required()
def view_cart():
    user_id = get_jwt_identity()
    items = CartItem.query.filter_by(user_id=user_id).all()
    out = []
    for it in items:
        p = it.product
        out.append({
            "cart_item_id": it.id,
            "product_id": p.id,
            "sku": p.sku,
            "name": p.name,
            "unit_price": p.unit_price,
            "quantity": it.quantity,
            "stock": p.stock
        })
    totals = compute_cart_totals(out, current_app.config['TAX_PERCENT'], current_app.config.get('DEFAULT_DISCOUNT_PERCENT',0.0))
    return jsonify(totals)

@cart_bp.route('/add', methods=['POST'])
@jwt_required()
def add_to_cart():
    user_id = get_jwt_identity()
    data = request.get_json() or {}
    product_id = data.get('product_id')
    qty = int(data.get('quantity',1))
    if not product_id:
        return jsonify({"msg":"product_id required"}), 400
    p = Product.query.get(product_id)
    if not p or not p.active:
        return jsonify({"msg":"product not found"}), 404
    if p.stock < qty:
        return jsonify({"msg":"insufficient stock", "available": p.stock}), 400

    existing = CartItem.query.filter_by(user_id=user_id, product_id=product_id).first()
    if existing:
        existing.quantity += qty
        if existing.quantity > p.stock:
            existing.quantity = p.stock
    else:
        item = CartItem(user_id=user_id, product_id=product_id, quantity=qty)
        db.session.add(item)
    db.session.commit()
    return jsonify({"msg":"added"}), 200

@cart_bp.route('/update', methods=['POST'])
@jwt_required()
def update_item():
    user_id = get_jwt_identity()
    data = request.get_json() or {}
    cart_item_id = data.get('cart_item_id')
    qty = int(data.get('quantity',1))
    if not cart_item_id:
        return jsonify({"msg":"cart_item_id required"}), 400
    it = CartItem.query.get_or_404(cart_item_id)
    if it.user_id != user_id:
        return jsonify({"msg":"forbidden"}), 403
    p = it.product
    if qty <= 0:
        db.session.delete(it)
    else:
        if qty > p.stock:
            return jsonify({"msg":"insufficient stock", "available": p.stock}), 400
        it.quantity = qty
    db.session.commit()
    return jsonify({"msg":"updated"}), 200

@cart_bp.route('/checkout', methods=['POST'])
@jwt_required()
def checkout():
    user_id = get_jwt_identity()
    items = CartItem.query.filter_by(user_id=user_id).all()
    if not items:
        return jsonify({"msg":"cart empty"}), 400
    line_items = []
    for it in items:
        p = it.product
        if p.stock < it.quantity:
            return jsonify({"msg":"insufficient stock for product", "product_id": p.id, "available": p.stock}), 400
        line_items.append({
            "product_id": p.id,
            "name": p.name,
            "unit_price": p.unit_price,
            "quantity": it.quantity
        })
    totals = compute_cart_totals(line_items, current_app.config['TAX_PERCENT'], current_app.config.get('DEFAULT_DISCOUNT_PERCENT',0.0))
    order = Order(user_id=user_id, total=totals['total'], items_json=json.dumps(line_items))
    db.session.add(order)
    for it in items:
        it.product.stock -= it.quantity
        db.session.delete(it)
    db.session.commit()
    return jsonify({"msg":"order placed", "order_id": order.id, "totals": totals}), 201
