from flask import Blueprint, request, jsonify
from ..models import Product
from ..extensions import db
from flask_jwt_extended import jwt_required

products_bp = Blueprint('products', __name__)

def product_to_dict(p):
    return {
        "id": p.id,
        "sku": p.sku,
        "name": p.name,
        "description": p.description,
        "unit_price": p.unit_price,
        "stock": p.stock,
        "active": p.active,
    }

@products_bp.route('/', methods=['GET'])
def list_products():
    q = Product.query.filter_by(active=True).all()
    return jsonify([product_to_dict(p) for p in q])

@products_bp.route('/<int:product_id>', methods=['GET'])
def get_product(product_id):
    p = Product.query.get_or_404(product_id)
    return jsonify(product_to_dict(p))

@products_bp.route('/', methods=['POST'])
@jwt_required()
def create_product():
    data = request.get_json() or {}
    p = Product(
        sku=data['sku'],
        name=data['name'],
        description=data.get('description',''),
        unit_price=float(data['unit_price']),
        stock=int(data.get('stock',0)),
        active=bool(data.get('active', True))
    )
    db.session.add(p)
    db.session.commit()
    return jsonify(product_to_dict(p)), 201

@products_bp.route('/<int:product_id>', methods=['PUT'])
@jwt_required()
def update_product(product_id):
    data = request.get_json() or {}
    p = Product.query.get_or_404(product_id)
    for k in ['sku','name','description','unit_price','stock','active']:
        if k in data:
            setattr(p, k, data[k])
    db.session.commit()
    return jsonify(product_to_dict(p)), 200

@products_bp.route('/<int:product_id>', methods=['DELETE'])
@jwt_required()
def delete_product(product_id):
    p = Product.query.get_or_404(product_id)
    p.active = False
    db.session.commit()
    return jsonify({"msg": "deleted"}), 200
