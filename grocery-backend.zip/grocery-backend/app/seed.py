from .extensions import db
from .models import Product, User
from . import create_app

def seed():
    app = create_app()
    with app.app_context():
        if not User.query.filter_by(email='user@example.com').first():
            u = User(email='user@example.com')
            u.set_password('password123')
            db.session.add(u)
        products = [
            {"sku":"P001","name":"Wheat Flour 5kg","unit_price":250.0,"stock":50},
            {"sku":"P002","name":"Rice 5kg","unit_price":400.0,"stock":60},
            {"sku":"P003","name":"Cooking Oil 1L","unit_price":150.0,"stock":100},
            {"sku":"P004","name":"Sugar 1kg","unit_price":45.0,"stock":200},
        ]
        for p in products:
            if not Product.query.filter_by(sku=p['sku']).first():
                prod = Product(sku=p['sku'], name=p['name'], unit_price=p['unit_price'], stock=p['stock'])
                db.session.add(prod)
        db.session.commit()
        print("Seeded.")
if __name__ == "__main__":
    seed()
