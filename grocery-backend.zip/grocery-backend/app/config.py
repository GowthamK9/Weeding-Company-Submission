import os
from dotenv import load_dotenv
from pathlib import Path

env_path = Path('.') / '.env'
if env_path.exists():
    load_dotenv(dotenv_path=env_path)

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'super-secret-change-me')
    SQLALCHEMY_DATABASE_URI = os.getenv('DATABASE_URL', 'sqlite:///grocery.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = os.getenv('JWT_SECRET_KEY', 'jwt-secret-change-me')
    TAX_PERCENT = float(os.getenv('TAX_PERCENT', 5.0))
    DEFAULT_DISCOUNT_PERCENT = float(os.getenv('DEFAULT_DISCOUNT_PERCENT', 0.0))
