import os
from flask import Flask, jsonify
from .config import Config
from .extensions import db, migrate, jwt
from .routes import register_routes

def create_app():
    app = Flask(__name__, static_folder=None)
    app.config.from_object(Config)

    # init extensions
    db.init_app(app)
    migrate.init_app(app, db)
    jwt.init_app(app)

    # register blueprints
    register_routes(app)

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({"msg": "Not found"}), 404

    return app
